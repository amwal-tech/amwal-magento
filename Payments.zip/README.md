# Amwal Payments Module for Magento 2

## Installation